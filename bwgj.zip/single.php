<?php get_header(); ?>


<div id="content">
<div id="contentleft">

<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>




<!-- 日志标题 -->
<div class="biaoti" id="masked">
<?php the_title(); ?>
</div>


	<!-- 标题下文章信息 -->
<div class="date2">

	<span class="date_fl">
	<span class="home"></span><a href="<?php bloginfo('url'); ?>" title="返回网站首页">首页</a> <b>></b>
 
    <?php the_category(',') ?> <!-- 分类 -->
	</span>
	<span class="date_zuozhe"><span class="pauthor"></span>作者：<?php the_author(); ?></span>

	<span><span class="ptime"></span><?php the_time('Y年n月j日'); ?></span>
	<span><span class="pview"></span>浏览：<?php get_post_views($post -> ID); ?></span>

	<span class="rz_ziti"><span class="zihao"></span>字号：<a href="#" id="small" class="hint--top  hint--success" data-hint="缩小到五号字体">小</a>

    <a href="#" id="medium" class="hint--top  hint--info" data-hint="适合阅读的小四字体">中</a>

    <a href="#" id="large" class="hint--top  hint--error" data-hint="放大到四号字体">大</a>
    </span>

	<span id="rz_pl">
	<a href="javascript:void(0);">
	<span class="plun"></span>评论：<?php comments_popup_link('暂无评论', '1', '%'); ?>
	</a></span>
	<!-- 如果用户已登录并具有权限，显示编辑链接 -->
	<span>
	<?php if(is_user_logged_in())  {?>
	<span class="bianji"></span><?php edit_post_link(); ?>
	<?php } ?>
	</span>


</div> <!-- end date2 -->
	
	<div class="xiantiao">
		<img src="<?php bloginfo('template_url'); ?>/images/xiantiao1.png">
	</div>
	



<!-- 日志全文内容 -->

<div id="rz_wz">
<?php the_content(); ?>
<div class="clear"></div>
</div>


	
	<!-- 统计访客停留时间 -->
	<div id="tingliu"><span class="tingliu2 hint--top hint--bounce" data-hint="希望这篇文章能给你带来收获，去发表评论吧！"><a href="javascript:void(0);"><img src="<?php bloginfo('template_url'); ?>/images/tishi.gif" class="tingliu5"></a></span> &nbsp;<span class="tingliu2">您阅读这篇文章共花了：</span>&nbsp;<span class="tingliu3" id="stime"></span></div>
<script language="JavaScript">var ss=0,mm=0,hh=0;function TimeGo(){ss++;if(ss>=60){mm+=1;ss=0}if(mm>=60){hh+=1;mm=0}ss_str=(ss<10?"0"+ss:ss);mm_str=(mm<10?"0"+mm:mm);tMsg=""+hh+"小时"+mm_str+"分"+ss_str+"秒";document.getElementById("stime").innerHTML=tMsg;setTimeout("TimeGo()",1000)}TimeGo();</script>
    <!-- 统计访客停留时间结束 -->
	
<!-- 分享 -->
<?php if(em_is_mobile()):?>

<div class="jiathis_style_24x24 fenxiang_sj">
	<a class="jiathis_button_weixin"></a>
	<a class="jiathis_button_qzone"></a>
	<a class="jiathis_button_tsina"></a>
	<a class="jiathis_button_tqq"></a>
	<a class="jiathis_button_tieba"></a>
	<a class="jiathis_button_cqq"></a>
	<a class="jiathis_button_douban"></a>
	<a href="http://www.jiathis.com/share?uid=1792395" class="jiathis jiathis_txt jtico jtico_jiathis" target="_blank"></a>
	<a class="jiathis_counter_style"></a>
</div>
<script type="text/javascript">
var jiathis_config = {data_track_clickback:'true'};
</script>
<script type="text/javascript" src="http://v3.jiathis.com/code/jia.js?uid=1367996005907460" charset="utf-8"></script>

<?php else:?>

<div class="jiathis_style_24x24 fenxiang"><a class="jiathis_button_weixin"></a><a class="jiathis_button_cqq"></a><a class="jiathis_button_qzone"></a><a class="jiathis_button_tsina"></a><a class="jiathis_button_tqq"></a><a class="jiathis_button_renren"></a><a class="jiathis_button_hi"></a><a class="jiathis_button_tieba"></a><a class="jiathis_button_tsohu"></a><a class="jiathis_button_t163"></a><a class="jiathis_button_douban"></a><a class="jiathis_button_tianya"></a><a class="jiathis_button_xiaoyou"></a><a class="jiathis_button_qq"></a><a class="jiathis_button_i139"></a><a class="jiathis_button_copy"></a><a class="jiathis_button_email"></a><a class="jiathis_button_ishare"></a><a href="http://www.jiathis.com/share?uid=1792395"class="jiathis jiathis_txt jtico jtico_jiathis"target="_blank"></a><a class="jiathis_counter_style"></a></div>
<script>var jiathis_config = {data_track_clickback:'true'};</script>
<script type="text/javascript" src="http://v3.jiathis.com/code/jia.js?uid=1367996005907460" charset="utf-8"></script>

<?php endif;?>

	<!-- 结束分割线 -->
	<div class="jieshu"><img src="<?php bloginfo('template_url'); ?>/images/jieshu.png"></div>
	<div class="jieshu2"><img src="<?php bloginfo('template_url'); ?>/images/jieshu3.gif"></div>
	


	<!-- 手机端上下篇 -->
	<div id="shangxiapian_2">

<?php
$prev_post = get_previous_post();
if (!empty( $prev_post )): ?>
		<div id="shangxiapian3">
	<a href="<?php echo get_permalink( $prev_post->ID ); ?>">
	<img src="<?php bloginfo('template_url'); ?>/images/shang2.png" onmouseover="this.src='<?php bloginfo('template_url'); ?>/images/shang1.png'" onmouseout="this.src='<?php bloginfo('template_url'); ?>/images/shang2.png'"></a>
		</div>
<?php endif; ?>

<?php
$next_post = get_next_post();
if (!empty( $next_post )): ?>
		<div id="shangxiapian4">
		<a href="<?php echo get_permalink( $next_post->ID ); ?>">
		<img src="<?php bloginfo('template_url'); ?>/images/xia2.png" onmouseover="this.src='<?php bloginfo('template_url'); ?>/images/xia1.png'" onmouseout="this.src='<?php bloginfo('template_url'); ?>/images/xia2.png'"></a>
		</div>
<?php endif; ?>
	<div class="clear"></div>
	</div>
	
<!-- pc 端上下篇 -->
	<div id="shangxiapian" data-kui-anim="slideInUp">
<?php
$prev_post = get_previous_post();
if (!empty( $prev_post )): ?>
  
	<div id="sxpbk1">
	<div id="anniu1">
	<a class="hint--right hint--bounce" data-hint="<?php echo $prev_post->post_title; ?>" href="<?php echo get_permalink( $prev_post->ID ); ?>" rel="external nofollow" >

	<img src="<?php bloginfo('template_url'); ?>/images/shangpian1.png" onmouseover="this.src='<?php bloginfo('template_url'); ?>/images/shangpian2.png'" onmouseout="this.src='<?php bloginfo('template_url'); ?>/images/shangpian1.png'"></a>
	</div>

	<div id="wzlj1"><?php echo $prev_post->post_title; ?></div>
	</div>
<?php endif; ?>


<?php
$next_post = get_next_post();
if (!empty( $next_post )): ?>

    <div id="sxpbk2">
    <div id="wzlj2"><?php echo $next_post->post_title; ?></div>
	
	<div id="anniu2">
	<a href="<?php echo get_permalink( $next_post->ID ); ?>" class="hint--left hint--bounce" data-hint="<?php echo $next_post->post_title; ?>">
		<img src="<?php bloginfo('template_url'); ?>/images/xiapian1.png" onmouseover="this.src='<?php bloginfo('template_url'); ?>/images/xiapian2.png'" onmouseout="this.src='<?php bloginfo('template_url'); ?>/images/xiapian1.png'"></a>
		</div>
		</div>

<?php endif; ?>
	<div class="clear"></div>
	</div>

	<!-- 感兴趣文章 -->

<div class="gxq" data-kui-anim="fadeInRight">
   	<div class="bti">
   		<img src="<?php bloginfo('template_url'); ?>/images/xiangguan.png">&nbsp;<span class="chaffle" data-lang="zh">相关文章</span>
   	</div>

    	<ul id="author_related">
<?php
  global $post;
  $post_author = get_the_author_meta( 'user_login' );
  $args = array(
        'author_name' => $post_author,
        'post__not_in' => array($post->ID),
        'showposts' => 6,               // 显示相关文章数量
        'orderby' => date,          // 按时间排序
        'caller_get_posts' => 1
    );
  query_posts($args);
  if (have_posts()) {
    while (have_posts()) {
      the_post(); update_post_caches($posts); ?>
  <li><a href="<?php the_permalink(); ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></li>
<?php
    }
  }
  else {
    echo '<li>暂无相关文章</li>';
  }
  wp_reset_query();
?>
		</ul>
<div class="clear"></div>
</div>


<div id="tag" data-kui-anim="slideInUp"><?php the_tags(); ?></div> 

<!-- 日志标签 -->



<div id="banquan" data-kui-anim="fadeInLeft">
	<!-- 二维码地址生成 -->
	<div class="tupian hint--right hint--rounded" data-hint="这篇文章太棒了，我要分享给我的小伙伴们！
	1、用手机扫二维码。2、点右上角分享到朋友圈。">
	<img src="http://qr.liantu.com/api.php?&bg=ffffff&w=100&m=6&fg=000000&text=<?php the_permalink(); ?>" alt="<?php the_title(); ?>">
	</div>


<div class="xinxi">
<span class="zuozhe">本文作者：</span><?php the_author(); ?> &nbsp;&nbsp;&nbsp;&nbsp;
<span class="biaoti2">文章标题：</span> <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a><br>
<span class="blog_url">本文地址：</span><a href="<?php the_permalink() ?>"><?php the_permalink() ?></a><br>
<b>版权声明：</b>若无注明，本文皆为“<span class="blog_name"><?php the_author(); ?></span>”原创，转载请保留文章出处。
</div>

<div class="clear"></div>

</div>

<div id="rz_pinglun" data-kui-anim="slideInUp">
<div class="pb_biaoti">
	<img src="<?php bloginfo('template_url'); ?>/images/plun.png">
</div>

<?php comments_template(); ?>
</div>

</div><!--end #contentleft-->


<?php endwhile; ?>
<?php endif;?>

<?php get_sidebar(); ?>
<?php get_footer(); ?>
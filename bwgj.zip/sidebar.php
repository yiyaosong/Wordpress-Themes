
<div id="sidebar">


<!-- 音乐 -->
<?php if ( of_get_option('music_id') ){?>
<div data-kui-anim="slideInUp" class="widget widget_music">
<h3 class="widget-title"><?php echo of_get_option('bwgj_music_bt', '音乐未设置保存'); ?></h3>
<div class="music">
<?php echo of_get_option('bwgj_music'); ?>
</div>
</div>
<?php }?>



<?php
if( is_active_sidebar( 'widget_default' ) ){
 echo '<div class="cbl_xgj">';
  dynamic_sidebar( 'widget_default' );
 echo '</div>';
}else{
 echo '<p>请设置小工具</p>';
}
?>



<div id="tongji" data-kui-anim="slideInUp">
<div id="tongji_biaoti"><span>网站统计</span></div>
<div id="tongjibiankuang"><div class="neirong">

  <li>建站日期：<?php echo of_get_option( 'bwgj_jzrq', '2016-8-1' ); ?></li>
  <li>运行天数：<?php echo floor((time()-strtotime(of_get_option('bwgj_jzrq', '未设置时间' )))/86400); ?> 天</li>
  <li>文章总数: <?php $count_posts = wp_count_posts(); echo $published_posts = $count_posts->publish;?> 篇</li>
  <li>草稿总数：<?php $users = $wpdb->get_var("SELECT COUNT(ID) FROM $wpdb->users"); echo $users; ?></li>
  <li>评论总数：<?php echo $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->comments");?> 条</li>
  <li>链接总数：<?php $link = $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->links WHERE link_visible = 'Y'"); echo $link; ?> 个</li>
  <li>分类总数: <?php echo $count_categories = wp_count_terms('category'); ?> 个</li>
  <li>标签数量：<?php echo $count_tags = wp_count_terms('post_tag'); ?> 个</li>
  <li>页面总数: <?php $count_pages = wp_count_posts('page'); echo $page_posts = $count_pages->publish; ?> 个</li>
  <li>用户总数：<?php $users = $wpdb->get_var("SELECT COUNT(ID) FROM $wpdb->users"); echo $users; ?> 人</li>
  <li>最后更新<span class="hongsezi">
	<?php $last = $wpdb->get_results("SELECT MAX(post_modified) AS MAX_m FROM $wpdb->posts WHERE (post_type = 'post' OR post_type = 'page') AND (post_status = 'publish' OR post_status = 'private')");$last = date('Y年n月j日 G:i:s', strtotime($last[0]->MAX_m));echo $last; ?>
  </span></li>
 <?php if(function_exists('performance')) performance(true) ;?>
</div></div></div>


</div><!-- end #sidebar -->
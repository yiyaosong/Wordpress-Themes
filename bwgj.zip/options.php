<?php

function optionsframework_option_name() {
	// Change this to use your theme slug
	return 'options-framework-theme';
}

function optionsframework_options() {

	// 测试数据
	$cbl_bt = array(
		'1' => __( '绿色', 'theme-textdomain' ),
		'2' => __( '暗紫', 'theme-textdomain' ),
		'3' => __( '淡紫', 'theme-textdomain' ),
		'4' => __( '正绿', 'theme-textdomain' ),
		'5' => __( '黑色', 'theme-textdomain' ),
		'6' => __( '橙色', 'theme-textdomain' ),
		'7' => __( '土古色', 'theme-textdomain' )
	);


	$options = array();

// 选项卡基本设置
// 
	$options[] = array(
		'name' => __( '基本设置', 'theme-textdomain' ),
		'type' => 'heading'
	);

// logo
	$options[] = array(
		'name' => __('logo', 'options_framework_theme'),
		'desc' => __('高度尺寸60px以下最好。', 'options_framework_theme'),
		'id' => 'bowen_logo',
		'type' => 'upload'
		);

// 个性鼠标开关
	$options[] = array(
		'name' => __( '个性鼠标开关', 'options_framework_theme' ),
		'desc' => __( '默认的鼠标样式看了几十年了还看不腻吗？那就用自个性化的。默认是开启的。', 'options_framework_theme' ),
		'id' => 'bwgj_cur',
		'std' => '1',
		'type' => 'checkbox'
	);

// 个性鼠标开关
	$options[] = array(
		'name' => __( '顶部大图上的logo与副标题开关', 'options_framework_theme' ),
		'desc' => __( '顶部大图里显示的logo和网站副标题开关，默认是显示的。', 'options_framework_theme' ),
		'id' => 'bwgj_logo2',
		'std' => '1',
		'type' => 'checkbox'
	);

// 公告开关
	$options[] = array(
		'name' => __( '公告开关', 'options_framework_theme' ),
		'desc' => __( '网站公告开关，默认只在首页显示。', 'options_framework_theme' ),
		'id' => 'bwgj_gg',
		'std' => '1',
		'type' => 'checkbox'
	);

// 公告文字
	$options[] = array(
		'name' => __( '网站公告文字', 'options_framework_theme' ),
		'desc' => __( '文字支持超链接的。', 'options_framework_theme' ),
		'id' => 'bwgj_ggwz',
		'std' => '这是一条网站首页的公告文字，演示链接<a href="http://qpjk.cc/" target="_blank" title="点击查看详情">www.qpjk.cc</a>',
		'type' => 'textarea'
	);

// 返回顶部
	$options[] = array(
		'name' => __( '返回顶部"去留言"链接', 'options_framework_theme' ),
		'desc' => __( '返回顶部中间的“评”字有两大功能。首页链接到留言板，日志页滚动到评论框处。在这里输入留言板地址即可。', 'options_framework_theme' ),
		'id' => 'bwgj_book',
		'std' => 'http://你的网站地址/book',
		'type' => 'text'
	);


// 友情链接开关
	$options[] = array(
		'name' => __('底部友情链接开关', 'options_framework_theme'),
		'desc' => __('底部友情链接默认是开启的。', 'options_framework_theme'),
		'id' => 'link2_kg',
		'std' => '1',
		'type' => 'checkbox'
		);

// 自定义底部导航
	$options[] = array(
		'name' => __( '自定义底部导航', 'theme-textdomain' ),
		'desc' => __( '自定义底部导航链接文字', 'theme-textdomain' ),
		'id' => 'db_nav',
		'std' => '
<a href="#" title="提示文字">自定义链接</a>|
<a href="#" title="提示文字">自定义链接</a>|
<a href="#" title="提示文字">自定义链接</a>|
<a href="#" title="提示文字">自定义链接</a>|
<a href="#" title="提示文字">自定义链接</a>|
		',
		'type' => 'textarea'
	);


// 侧边栏设置
	$options[] = array(
		'name' => __( '侧边栏设置', 'theme-textdomain' ),
		'type' => 'heading'
	);

// 边栏标题框选择
	$options[] = array(
		'name' => __( '边栏小工具标题框选择', 'theme-textdomain' ),
		'desc' => __( '侧边栏小工具的标题框选择，预设了7种样式。', 'theme-textdomain' ),
		'id' => 'bwgj_xgj_bt',
		'std' => '1',
		'type' => 'radio',
		'options' => $cbl_bt
	);

// 音乐开关
	$options[] = array(
		'name' => __('音乐开关', 'options_framework_theme'),
		'desc' => __('边栏音乐开关', 'options_framework_theme'),
		'id' => 'music_id',
		'std' => '1',
		'type' => 'checkbox'
		);

// 音乐标题文字
	$options[] = array(
		'name' => __('音乐标题文字', 'options_framework_theme'),
		'desc' => __('修改音乐标题上的文字', 'options_framework_theme'),
		'id' => 'bwgj_music_bt',
		'std' => '精选音乐',
		'class' => 'mini',	//该类型元素class
		'type' => 'text'
	);

// 音乐
	$options[] = array(
		'name' => __( '音乐代码', 'theme-textdomain' ),
		'desc' => __( '粘贴您的“网易云音乐播放器”代码在这里。進入<a href="http://music.163.com/">http://music.163.com/</a>，然后点一个音乐专辑或你自己的收藏的专辑，点下面的“生成外链播放器”，然后得到调用代码，宽度请修改成276，高度不变。框架的宽度必须是296。auto=0，0是不自动播放，1是自动播放。', 'theme-textdomain' ),
		'id' => 'bwgj_music',
		'std' => '
<iframe frameborder="no" border="0" marginwidth="0" marginheight="0" width=296 height=450 src="http://music.163.com/outchain/player?type=1&id=3164858&auto=0&height=430"></iframe>
		',
		'type' => 'editor'
	);


// 建站日期
	$options[] = array(
		'name' => __( '建站日期', 'theme-textdomain' ),	//选项的名称
		'desc' => __( '填写建站日期格式：2016-8-1', 'theme-textdomain' ),	//介绍
		'id' => 'bwgj_jzrq',	//必填，唯一标示
		'std' => '2016-8-1',	//元素默认值
		'type' => 'text'	//表单元素类型
	);

// 关于我
	$options[] = array(
		'name' => __( '意见反馈', 'theme-textdomain' ),
		'type' => 'heading'
	);

	/**
	 * For $settings options see:
	 * http://codex.wordpress.org/Function_Reference/wp_editor
	 *
	 * 'media_buttons' are not supported as there is no post to attach items to
	 * 'textarea_name' is set by the 'id' you choose
	 */

	$wp_editor_settings = array(
		'wpautop' => true, // Default
		'textarea_rows' => 5,
		'tinymce' => array( 'plugins' => 'wordpress,wplink' )
	);

	$options[] = array(
		'name' => __( '关于我', 'theme-textdomain' ),
		'desc' => sprintf( __( '一个号称“清萍剑客”的人，好动画、喜设计，不甘于平庸之作，不合同世俗之见。以自由、梦幻、玄奇、动画特效设计理念为主。学海无涯、艺无止境，希望能得到更多同道的指点而提升。' ), '' ),
	);

	$options[] = array(
		'name' => __( '欢迎自由修改', 'theme-textdomain' ),
		'desc' => sprintf( __( '欢迎二次、三次修改，让我们一起来完美它，使他流光溢彩、充塞天下。
			如果你有二次修改请在 “Powered by wordpress Theme by 清萍剑客” 后面加上你的 by 名字。
			修改不错的请发给我一份哟，我也收藏。' ), '' ),
	);

	$options[] = array(
		'name' => __( '关于版权', 'theme-textdomain' ),
		'desc' => sprintf( __( '模板虽免费，版权仍归我。
			如果你要删除主题版权请支付作者 50￥ 的授权费。
			如果你又想去掉版权，又不想付费，也欢迎你使用！
			' ), '' ),
	);

	$options[] = array(
		'name' => __( '联系我', 'theme-textdomain' ),
		'desc' => sprintf( __( '
			网站：<a href="http://qpjk.cc/">www.qpjk.cc</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			留言板：<a href="http://qpjk.cc/book/">qpjk.cc/book</a> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			QQ：1921257873 &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				微信：mingjian9941
			
			' ), '' ),
	);


	return $options;
}
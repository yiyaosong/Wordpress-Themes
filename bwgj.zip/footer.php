</div><!--end #content-->

<div class="clear"></div>


<div id="footerbar" role="contentinfo" data-kui-anim="slideInUp">
<div id="dibu">
	<a id="gotop" href="javascript:void(0);">返回顶部</a>|
	<?php echo of_get_option( 'db_nav', '自定义链接 | ' ); ?>
	<!-- 自定义底部导航 -->
	<a href="<?php bloginfo('url'); ?>/wp-admin/" class="hint--right hint--error" data-hint="站长的后花园，闲人止步！ ^_^">后花园</a>

<p id="db_bqwz">
<span>
Copyright © <?php echo date('Y'); ?> <a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a> &nbsp;
</span>
</p>
<!-- 主题虽免费，版权依然在。如果你要删除主题版权请支付作者50￥的版权费。作者QQ：1921257873  留言板：qpjk.cc/book -->

<?php if ( of_get_option('link2_kg') ){?>
<!-- 友情链接 -->
<?php if ( (is_home() || is_front_page()) && !is_paged() ) { ?>
	<div id="link2">
<?php
$default_ico = get_template_directory_uri().'/images/links.png';
$bookmarks = get_bookmarks('orderby=rand');
if ( !empty($bookmarks) ) {
foreach ($bookmarks as $bookmark) {
echo '<li><a href="' . $bookmark->link_url . '" title="' . $bookmark->link_description . '"><img src="', $bookmark->link_url , '/favicon.ico" onerror="javascript:this.src=\'' , $default_ico , '\'">' . $bookmark->link_name . '</a></li>';}
}
?>
	</div>
<?php } ?>
<?php }?>

</div><!--end #dibu-->
</div><!--end #footerbar-->


</div><!--end #wrap-->



<!-- 返回顶部代码开始 -->
<div id="shangxia" class="animated bounceInUp">
<div id="shang"></div>
<div id="comt">

<!-- 如果是首页点击就去留言板 -->

<?php if ( is_home() || is_front_page() ) { ?>
<a id="sx_book" class="hint--left hint--bounce" data-hint="去留言" href="<?php echo of_get_option( 'bwgj_book', '/book/' ); ?>"></a>
<?php } ?>

<!-- 如果是文章页或页面点击就去评论框 -->
<?php if ( is_single() || is_page() ) { ?>
<a id="ping" class="hint--left hint--bounce" data-hint="去评论"></a>
<?php } ?>


</div>
<div id="xia"></div>
</div><!-- 返回顶部代码 结束 -->



 <!-- 底部横幅代码开始 -->
 <div id="bottom_banner">
<img src="<?php bloginfo('stylesheet_directory');?>/images/dibuhengfu.png">
</div>

<!-- 底部横幅代码结束 -->


<script src="<?php bloginfo('template_url'); ?>/jcss/bowenguangji.min.js"></script>
<script src="http://cdn.bootcss.com/gsap/1.19.0/TweenMax.min.js"></script>
<script>window.jQuery || document.write('<script src="<?php bloginfo('template_url'); ?>/jcss/TweenMax.min.js">\x3C/script>')</script>
<script src="<?php bloginfo('template_url'); ?>/jcss/ScrollToPlugin.min.js"></script>

<?php wp_footer();?>
</body>
</html>
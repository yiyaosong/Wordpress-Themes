<?php get_header(); ?>

<div id="content">
<div id="contentleft">

<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>

	<h2 class="biaoti" id="masked">
		<?php the_title(); ?>
	</h2>

	<div class="xiantiao2">
		<img src="<?php bloginfo('template_url'); ?>/images/xiantiao2.png">
	</div>

	<div id="rz_wz">

		<?php the_content(); ?>

	</div>
	<div class="clear"></div>

	<br>

<?php if ( comments_open() ) { ?>
	<div id="rz_pinglun">
		<div class="pb_biaoti">
			<img src="<?php bloginfo('template_url'); ?>/images/plun.png">
		</div>

	<?php comments_template(); ?>
</div>
<?php } ?>

</div><!--end #contentleft-->


<?php endwhile; ?>
<?php endif;?>


<?php get_sidebar(); ?>
<?php get_footer(); ?>
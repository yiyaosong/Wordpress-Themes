<!doctype html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="utf-8">
	<title><?php wp_title(); ?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="renderer" content="webkit"> <!-- 默认用极速核 -->
	<meta http-equiv="Cache-Control" content="no-siteapp"> <!-- 禁止百度转码 -->
	<meta name="description" content="<?php bloginfo('description'); ?>">
	<meta name="generator" content="清萍工作室 qpjk.cc">

	<!-- 引用百度cdn公共库网站托管的Jquery，不成功则使用本地Jquery。 -->
	<script src="http://libs.baidu.com/jquery/1.11.1/jquery.min.js"></script>
	<script>!window.jQuery && document.write('<script src="<?php bloginfo('template_url'); ?>/jcss/jquery-1.11.1.min.js"><\/script >');</script>

	<link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet">
	<link href="<?php bloginfo('template_url'); ?>/jcss/animate.min.css" rel="stylesheet">

	<!-- 工具提示css -->
	<link href="<?php bloginfo('template_url'); ?>/jcss/hint.min.css" rel="stylesheet">

	<!--[if lt IE 9]>
    <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/jcss/html5-css3"></script>
	<![endif]-->

	<style>
	<?php if ( of_get_option('bwgj_cur') ){?>
	body {cursor: url(<?php bloginfo('template_url'); ?>/images/zhizhen.ani), url(<?php bloginfo('template_url'); ?>/images/zhizhen4.cur), auto;}

	a{cursor: url(<?php bloginfo('template_url'); ?>/images/Click.ani), url(<?php bloginfo('template_url'); ?>/images/zhizhen3.cur), auto;} 
	#shang, #comt, #xia {cursor: url(<?php bloginfo('template_url'); ?>/images/Click.ani), url(<?php bloginfo('template_url'); ?>/images/zhizhen3.cur), auto;}
	<?php } ?>

	h3.widget-title,#tongji_biaoti {
    background: url(<?php bloginfo('template_url'); ?>/images/biaoti<?php echo of_get_option( 'bwgj_xgj_bt', '1' ); ?>.gif) no-repeat center;
	}
	</style>


<!-- 预加载页面 -->
<?php if (is_archive() && ($paged > 1) && ($paged < $wp_query->max_num_pages)) { ?>
<link rel="prefetch" href="<?php echo get_next_posts_page_link(); ?>">
<link rel="prerender" href="<?php echo get_next_posts_page_link(); ?>">
<?php } elseif (is_singular()) { ?>
<link rel="prefetch" href="<?php bloginfo('home'); ?>">
<link rel="prerender" href="<?php bloginfo('home'); ?>">
<?php } ?>
<!-- end 预加载页面 -->


<?php wp_head(); ?>
</head>
<body>
	<!-- 顶部横幅随机图片31张，更多横幅请查看www.qpjk.cc-->

<div id="top_banner" class="animated fadeIn">

<?php if ( of_get_option('bwgj_logo2') ){?>
<div id="bwgj_logo2">
	<img src="<?php bloginfo('template_url'); ?>/images/logo.png">
	<br>
	<span><?php echo get_bloginfo('description'); ?></span>
</div>
<?php } ?>


<?php $random_image = rand(1, 31); ?>
<img src="<?php bloginfo('stylesheet_directory');?>/images/bg/top_banner<?php echo $random_image; ?>.jpg">
</div>


<!-- 800px分辨率才出现的顶部logo 宽高:260×63 宽高不局限，大家自己看着设计。 其中class="Tada" 是响铃动画，不想要直接删除这句。-->
<div id="bwgj_logo">
<a href="<?php bloginfo('url');?>" title="点击返回首页"><img src="<?php echo of_get_option( 'bowen_logo', '/wp-content/themes/bowenguangji/images/logo.png' ); ?>" class="animated tada"></a>
</div>





<!-- 搜索框：800px分辨率才出现的。 -->

<div id="sousuo2">
<form action="/" method="get">
<input name="s" type="search" value="<?php the_search_query(); ?>" placeholder="框中输文字，回车索结果。"></form></div>


<div id="wrap">
<!-- 导航菜单 -->
<div id="nav">
	<?php wp_nav_menu(
		array(
			'theme_location' => 'nav1',
			'fallback_cb' => 'top_nav_fallback'
	) ); ?>
</div>


<!-- 首页公告，只在首页显示。-->
<?php if ( of_get_option('bwgj_gg') ){?>
	<?php if ( (is_home() || is_front_page()) && !is_paged() ) { ?>
<div id="gonggao" class="animated flipInX">
     <div id="ggwz">
		<?php echo of_get_option( 'bwgj_ggwz', '' ); ?>
     </div>
     <div id="gonggao_img"><img src="<?php bloginfo('template_url'); ?>/images/gonggao.png"></div>
    </div>
<?php } ?>
<?php } ?>




<?php
/**
 * The template for displaying 404 pages (not found).
 *
 * @link https://codex.wordpress.org/Creating_an_Error_404_Page
 *
 * @package bowenguangji  www.qpjk.cc
 */

 ?>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title itemprop="name"><?php global $page, $paged;wp_title( '|', true, 'right' );
bloginfo( 'name' );$site_description = get_bloginfo( 'description', 'display' );
if ( $site_description && ( is_home() || is_front_page() ) ) echo " | $site_description";if ( $paged >= 2 || $page >= 2 ) echo ' | ' . sprintf( __( '第 %s 页'), max( $paged, $page ) );?>
</title>
<link href="<?php bloginfo('template_url'); ?>/jcss/animate.min.css" rel="stylesheet">
<style>
body {
    background: url(<?php bloginfo('template_url'); ?>/images/bg.jpg);
}

section.wzd_404 {
    text-align: center;
    font-size: 18px;
    margin-top: 120px;
}

section.wzd_404>img{
  animation: wobble 5s infinite;
}

p{margin-top: 30px;}

p>a {
    padding: 10px 30px;
}
</style>

</head>
<body <?php body_class(); ?>>
<section class="wzd_404 animated bounceInDown">
<img src="<?php bloginfo('template_url'); ?>/images/weizhaodao.gif">
<p>
<a href=javascript:history.go(-1);>返回上一页</a>
<a href="<?php bloginfo('url');?>">返回主页</a>  
</p>
</section>
</body>
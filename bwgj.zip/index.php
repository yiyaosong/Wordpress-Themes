<?php get_header(); ?>

<div id="content">
<div id="contentleft">


<?php if (have_posts()) : while (have_posts()) : the_post(); ?> 

<div id="bw_lb" data-kui-anim="fadeInUp">
<!-- 标题 -->
<h2 class="loading">
<a href="<?php the_permalink(); ?>" rel="bookmark">
<?php the_title(); ?>
</a>
</h2>

<!-- 标题信息 -->
<div class="date1">
	<span><span class="ptime"></span>时间：<?php the_time('Y年n月j日') ?></span>
	<span class="date_zuozhe"><span class="pauthor"></span>作者：<?php the_author(); ?></span>
	<span class="date_fl"><span class="pcata"></span>分类：<?php the_category(); ?></span>
	<span><span class="pview"></span>浏览：<?php get_post_views($post -> ID); ?></span>
	<span><span class="plun"></span><a href=""><?php comments_popup_link('评论：0 条', '评论：1条', '评论：% 条', '', '评论已关闭'); ?></a></span>
	<span>
	<?php if(is_user_logged_in())  {?>
	<span class="bianji"></span><?php edit_post_link(); ?>
	<?php } ?>
	</span>
</div>
	
	<?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 200,"……"); ?>
	<div class="clear"></div>


<!-- 阅读全文 -->
<div class="yueduqw">
<a href="<?php the_permalink(); ?>">
	<img src="<?php bloginfo('template_url'); ?>/images/ydqw1.gif" onmouseover="this.src='<?php bloginfo('template_url'); ?>/images/ydqw2.gif'" onmouseout="this.src='<?php bloginfo('template_url'); ?>/images/ydqw1.gif'" alt="继续阅读全文。">
</a>
</div>

	<div class="clear"></div>
	<div class="line"></div>
</div> <!-- end #bw_lb -->

<?php endwhile; ?>   
<?php else : ?>
	<style>
	#sidebar{display:none;}
	#contentleft {
    width: 95%;
    float: none;
}
	</style>
    <div class="sy_zbd">未找到该分类及文章……</div>   
<?php endif; ?> 



<!-- 分页 -->
<?php if(function_exists('bowen_page_nav')) bowen_page_nav(); ?>

</div><!-- end #contentleft-->



<?php get_sidebar(); ?>
<?php get_footer(); ?>
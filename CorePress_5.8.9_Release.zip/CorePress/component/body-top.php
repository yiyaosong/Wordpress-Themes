
<?php
global $set;
if ($set['theme']['loadbar'] == 1) {
    echo "<script>NProgress.start();</script>";
}
?>
